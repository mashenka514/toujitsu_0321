public class ForPractice04 {
    public static void main(String[] args) {
        int count = 0;
        for (int i =0;i <= 4;i++){
            System.out.println(count);
            count ++;

        }

    }
}
