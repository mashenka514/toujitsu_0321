/*import java.util.Scanner;

public class ObjectPractice03 {
    public static void main(String[] args) {
        final double pai = 3.14;
        Scanner stdIn = new Scanner(System.in);

        System.out.println("半径：");
        double r = stdIn.nextDouble();

        System.out.println("円周の長さは" + 2 * pai * r + "です。");
        System.out.println("円の面積は" + pai * r * r + "です。");
    }
}
*/

//Circleを呼び出すクラス
public class ObjectPractice03{
    public static void main(String[] args) {
        //1つめのオブジェクト
        Circle koushiki3 = new Circle(20);
        //メソッドの呼び出し
        koushiki3.getArea();
        koushiki3.getCircumference();

    }

}