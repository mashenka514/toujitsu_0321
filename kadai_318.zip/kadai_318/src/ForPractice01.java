/*public class ForPractice01 {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++){
            System.out.println("*");
        }
    }
}*/
//↑これは2番目の課題の結果になった

public class ForPractice01{
    public static void main(String[] args) {
             for (int i = 1; i <= 10; i++){
                System.out.print("*");
            }
        }
}
//printとprintlnの違い　　改行があるかないか
//println( )メソッドは引数で指定された内容の後ろに改行を入れます。