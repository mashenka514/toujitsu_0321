public class ForPractice05 {
    public static void main(String[] args) {
        for (int n = 1;n <= 5; n++){
            String asta = "*";
            for (int i = 1;i <= 5; i++){
            System.out.print(asta);
            }
            System.out.println(asta);
        }
    }
}















