package com.kadai.toujitsu.kadai1.kadai1;

public class ObjectPractice05 {
    public static void main(String[] args) {

    }
}
