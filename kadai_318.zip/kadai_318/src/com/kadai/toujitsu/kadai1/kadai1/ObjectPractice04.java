package com.kadai.toujitsu.kadai1.kadai1;

public class ObjectPractice04 {
    public static void main(String[] args) {
        Person Shain1 = new Person("丸山","神奈川");
        //結果が表示されない
    }
}
