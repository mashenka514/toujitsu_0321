package com.kadai.toujitsu.kadai1.kadai1;

public class Person {
    //フィールド
    public String namae;
    public String shussin;
    //コンストラクタ
    public Person(String namae,String shussin){
        this.namae = "丸山";
        this.shussin = "神奈川";
    }
    //メソッド
    public void getSelfIntroduction(){
        System.out.println("私の名前は"+this.namae+"です。"+this.shussin+"出身です。");
    }
}
