package com.kadai.toujitsu.kadai1.kadai1;

public class ForPractice07 {
    public static void main(String[] args) {
        for (int n = 1;n <= 4;n++){
            String asta = "*";
            for (int i = 1;i <= 4;i++){
                System.out.print(asta);
            }
          //  asta = asta - asta;
            //こちらもやり方わかったのですが時間がなかったのでいったんこれで提出します
        }
    }
}
