public class ForPractice06 {
    public static void main(String[] args) {
        for (int n = 1;n <= 4; n++){
            String asta = "";
            if (n == 1){
                for (int i = 1;i <= 1;i++){
                    asta = "*";
                    System.out.print(asta);
                    //asta = asta + asta;
                    //アスタリスクをひとつづつ足していこうとしたが、うまくいかなかった
                }
            }else if(n == 2){
                for (int i = 1;i <= 2;i++){
                    asta = "*";
                    System.out.print(asta);

                }
            }else if(n == 3){
                for (int i = 1;i <= 3;i++){
                    asta = "*";
                    System.out.print(asta);

                }
            }else if(n == 4){
                for (int i = 1;i <= 4;i++){
                    asta = "*";
                    System.out.print(asta);

                }
            }

            System.out.println();


        }
    }
}
