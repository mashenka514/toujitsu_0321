public class ObjectPractice01 {
    public static void main(String[] args) {
        Circle koushiki1 = new Circle();
        koushiki1.getArea();
        koushiki1.getCircumference();
    }
}
