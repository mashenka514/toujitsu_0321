public class ForPractice03 {
    public static void main(String[] args) {
        int count = 0;
        for (int i =0;i <= 9;i++){
            System.out.print(count);
            count ++;

    }

    }
}
