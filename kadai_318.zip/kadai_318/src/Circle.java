public class Circle {
	//フィールド
	public int radius;
	//コンストラクタ
	public Circle()
	{
		this.radius = 5;
	}
	public Circle(int radius) {
		this.radius = radius;
	}
	//メソッド
	public void getArea()
	{
		System.out.println("半径が"+radius+"の円の面積は"+radius * radius * 3.14+"です。");
	}
	public void getCircumference()
	{
		System.out.println("半径が"+radius+"の円周は"+2 * radius * 3.14+"です。");
	}
}
