public class ObjectPractice02 {
    public static void main(String[] args) {
        Circle koushiki2 = new Circle(10);
        koushiki2.getArea();
        koushiki2.getCircumference();
    }
}
